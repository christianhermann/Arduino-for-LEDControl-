class LED {

  //Class variables
  uint8_t LEDpin;  //used pin
  uint8_t PWMpin;  //used PWM pin
  uint8_t  LEDpinBitHigh;
  uint8_t  LEDpinBitLow;
  uint8_t pwmVal;        //used intensity
  unsigned long tOn;     //microseconds time on
  unsigned long tPause;  //microseconds time off
  static uint8_t volatile* port;
  bool currentState;  //true = high; false = low;
  unsigned long lastSwichTime;

public:
  LED();



  void create_LED(uint8_t LEDpin, uint8_t pwmVal, unsigned long tOn, unsigned long tOff) {
    tOn = tOn;
    tOff = tOff;
    currentState = false;

    switch (LEDpin) {
      case 1:
        {
          LEDpin = 23;
          PWMpin = 4;
          LEDpinBitHigh = B00000010;
          LEDpinBitLow = B11111101;
          port = &PORTA;
        }
      case 4:
        {
          LEDpin = 29;
          PWMpin = 7;
          port = &PORTA;
          LEDpinBitHigh = B10000000;
          LEDpinBitLow = B01111111;
        }
    }
    analogWrite(PWMpin, pwmVal);
  }

  void Update() {
    unsigned long currentTime = micros();

    if((currentState) && (currentTime - lastSwichTime >= tOn))
    {
      currentState = false;
      lastSwichTime = currentTime;
      *port &= LEDpinBitLow;
    } else if ((!currentState) && (currentTime - lastSwichTime >= tPause))
    {
      currentState = true;
      lastSwichTime = currentTime;
      *port |= LEDpinBitHigh; 
    }
  }
};